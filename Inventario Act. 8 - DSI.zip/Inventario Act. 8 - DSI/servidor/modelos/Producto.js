const db = require('../config/baseDeDatos');

const crearProducto = (nombre, categoria, precio, stock, descripcion, callback) => {
    const consulta = `INSERT INTO Producto (nombre, categoria, precio, stock, descripcion) VALUES (?, ?, ?, ?, ?)`;
    db.run(consulta, [nombre, categoria, precio, stock, descripcion], function (error) {
        if (error) {
            callback(error, null);
        } else {
            callback(null, { id: this.lastID, nombre, categoria, precio, stock, descripcion });
        }
    });
};

const obtenerTodosLosProductos = (callback) => {
    const consulta = `SELECT * FROM Producto`;
    db.all(consulta, [], (error, filas) => {
        if (error) {
            callback(error, null);
        } else {
            callback(null, filas);
        }
    });
};

const obtenerProductoPorId = (id, callback) => {
    const consulta = `SELECT * FROM Producto WHERE id = ?`;
    db.get(consulta, [id], (error, fila) => {
        if (error) {
            callback(error, null);
        } else {
            callback(null, fila);
        }
    });
};

const actualizarProducto = (id, nombre, categoria, precio, stock, descripcion, callback) => {
    const consulta = `UPDATE Producto SET nombre = ?, categoria = ?, precio = ?, stock = ?, descripcion = ? WHERE id = ?`;
    db.run(consulta, [nombre, categoria, precio, stock, descripcion, id], function (error) {
        if (error) {
            callback(error, null);
        } else {
            callback(null, { cambios: this.changes });
        }
    });
};

const eliminarProducto = (id, callback) => {
    const consulta = `DELETE FROM Producto WHERE id = ?`;
    db.run(consulta, [id], function (error) {
        if (error) {
            callback(error, null);
        } else {
            callback(null, { cambios: this.changes });
        }
    });
};

module.exports = {
    crearProducto,
    obtenerTodosLosProductos,
    obtenerProductoPorId,
    actualizarProducto,
    eliminarProducto
};
