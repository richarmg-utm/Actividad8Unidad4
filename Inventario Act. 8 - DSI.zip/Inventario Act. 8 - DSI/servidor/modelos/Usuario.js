const db = require('../config/baseDeDatos');

const crearUsuario = (nombre, correo, clave, rol, callback) => {
    const consulta = `INSERT INTO Usuario (nombre, correo, clave, rol) VALUES (?, ?, ?, ?)`;
    db.run(consulta, [nombre, correo, clave, rol], function (error) {
        if (error) {
            callback(error, null);
        } else {
            callback(null, { id: this.lastID, nombre, correo, rol });
        }
    });
};

const buscarUsuarioPorCorreo = (correo, callback) => {
    const consulta = `SELECT * FROM Usuario WHERE correo = ?`;
    db.get(consulta, [correo], (error, fila) => {
        if (error) {
            callback(error, null);
        } else {
            callback(null, fila);
        }
    });
};

const obtenerTodosLosUsuarios = (callback) => {
    const consulta = `SELECT id, nombre, correo, rol FROM Usuario`;
    db.all(consulta, [], (error, filas) => {
        if (error) {
            callback(error, null);
        } else {
            callback(null, filas);
        }
    });
};

module.exports = {
    crearUsuario,
    buscarUsuarioPorCorreo,
    obtenerTodosLosUsuarios
};
