const db = require('../config/baseDeDatos');

const registrarMovimiento = (tipo, cantidad, productoId, callback) => {
    const fecha = new Date().toISOString();
    const consulta = `INSERT INTO HistorialMovimiento (tipo, cantidad, fecha, producto_id) VALUES (?, ?, ?, ?)`;

    db.run(consulta, [tipo, cantidad, fecha, productoId], function (error) {
        if (error) {
            callback(error, null);
        } else {
            callback(null, { id: this.lastID, tipo, cantidad, fecha, productoId });
        }
    });
};

const obtenerHistorialPorProducto = (productoId, callback) => {
    const consulta = `SELECT * FROM HistorialMovimiento WHERE producto_id = ? ORDER BY fecha DESC`;
    db.all(consulta, [productoId], (error, filas) => {
        if (error) {
            callback(error, null);
        } else {
            callback(null, filas);
        }
    });
};

const obtenerTodoElHistorial = (callback) => {
    const consulta = `
    SELECT h.*, p.nombre as nombre_producto 
    FROM HistorialMovimiento h
    INNER JOIN Producto p ON h.producto_id = p.id
    ORDER BY h.fecha DESC
  `;
    db.all(consulta, [], (error, filas) => {
        if (error) {
            callback(error, null);
        } else {
            callback(null, filas);
        }
    });
};

module.exports = {
    registrarMovimiento,
    obtenerHistorialPorProducto,
    obtenerTodoElHistorial
};
