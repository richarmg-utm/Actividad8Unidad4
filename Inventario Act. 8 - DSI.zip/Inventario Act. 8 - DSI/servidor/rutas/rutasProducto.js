const express = require('express');
const {
    listarProductos,
    obtenerProducto,
    agregarProducto,
    modificarProducto,
    borrarProducto
} = require('../controladores/controladorProducto');
const { verificarToken } = require('../middlewares/autenticacion');

const enrutador = express.Router();

enrutador.get('/', verificarToken, listarProductos);
enrutador.get('/:id', verificarToken, obtenerProducto);
enrutador.post('/', verificarToken, agregarProducto);
enrutador.put('/:id', verificarToken, modificarProducto);
enrutador.delete('/:id', verificarToken, borrarProducto);

module.exports = enrutador;
