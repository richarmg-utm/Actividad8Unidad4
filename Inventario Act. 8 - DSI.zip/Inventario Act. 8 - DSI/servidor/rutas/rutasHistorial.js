const express = require('express');
const { listarHistorialCompleto, listarHistorialProducto } = require('../controladores/controladorHistorial');
const { verificarToken } = require('../middlewares/autenticacion');

const enrutador = express.Router();

enrutador.get('/', verificarToken, listarHistorialCompleto);
enrutador.get('/producto/:productoId', verificarToken, listarHistorialProducto);

module.exports = enrutador;
