const jwt = require('jsonwebtoken');
const { CLAVE_SECRETA } = require('../controladores/controladorUsuario');

const verificarToken = (req, res, next) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(403).json({ mensaje: 'Token no proporcionado' });
    }

    const tokenLimpio = token.startsWith('Bearer ') ? token.slice(7) : token;

    jwt.verify(tokenLimpio, CLAVE_SECRETA, (error, decodificado) => {
        if (error) {
            return res.status(401).json({ mensaje: 'Token inválido o expirado' });
        }

        req.usuario = decodificado;
        next();
    });
};

module.exports = { verificarToken };
