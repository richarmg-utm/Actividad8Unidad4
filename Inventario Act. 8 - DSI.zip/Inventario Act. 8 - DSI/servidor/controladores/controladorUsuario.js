const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { crearUsuario, buscarUsuarioPorCorreo } = require('../modelos/Usuario');

const CLAVE_SECRETA = 'clave_secreta_jwt_inventario_2024';

const registrarUsuario = async (req, res) => {
    try {
        const { nombre, correo, clave, rol } = req.body;

        if (!nombre || !correo || !clave) {
            return res.status(400).json({ mensaje: 'Todos los campos son obligatorios' });
        }

        buscarUsuarioPorCorreo(correo, async (error, usuarioExistente) => {
            if (error) {
                return res.status(500).json({ mensaje: 'Error al verificar usuario', error: error.message });
            }

            if (usuarioExistente) {
                return res.status(400).json({ mensaje: 'El correo ya está registrado' });
            }

            const claveEncriptada = await bcrypt.hash(clave, 10);

            crearUsuario(nombre, correo, claveEncriptada, rol || 'usuario', (error, nuevoUsuario) => {
                if (error) {
                    return res.status(500).json({ mensaje: 'Error al crear usuario', error: error.message });
                }

                res.status(201).json({ mensaje: 'Usuario registrado exitosamente', usuario: nuevoUsuario });
            });
        });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor', error: error.message });
    }
};

const iniciarSesion = async (req, res) => {
    try {
        const { correo, clave } = req.body;

        if (!correo || !clave) {
            return res.status(400).json({ mensaje: 'Correo y clave son obligatorios' });
        }

        buscarUsuarioPorCorreo(correo, async (error, usuario) => {
            if (error) {
                return res.status(500).json({ mensaje: 'Error al buscar usuario', error: error.message });
            }

            if (!usuario) {
                return res.status(401).json({ mensaje: 'Credenciales incorrectas' });
            }

            const claveValida = await bcrypt.compare(clave, usuario.clave);

            if (!claveValida) {
                return res.status(401).json({ mensaje: 'Credenciales incorrectas' });
            }

            const token = jwt.sign(
                { id: usuario.id, correo: usuario.correo, rol: usuario.rol },
                CLAVE_SECRETA,
                { expiresIn: '24h' }
            );

            res.json({
                mensaje: 'Inicio de sesión exitoso',
                token,
                usuario: {
                    id: usuario.id,
                    nombre: usuario.nombre,
                    correo: usuario.correo,
                    rol: usuario.rol
                }
            });
        });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor', error: error.message });
    }
};

module.exports = {
    registrarUsuario,
    iniciarSesion,
    CLAVE_SECRETA
};
