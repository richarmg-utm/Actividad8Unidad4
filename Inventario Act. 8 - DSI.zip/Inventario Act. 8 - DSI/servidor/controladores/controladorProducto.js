const db = require('../config/baseDeDatos');
const {
    crearProducto,
    obtenerTodosLosProductos,
    obtenerProductoPorId,
    actualizarProducto,
    eliminarProducto
} = require('../modelos/Producto');
const { registrarMovimiento } = require('../modelos/HistorialMovimiento');

const listarProductos = (req, res) => {
    obtenerTodosLosProductos((error, productos) => {
        if (error) {
            return res.status(500).json({ mensaje: 'Error al obtener productos', error: error.message });
        }
        res.json(productos);
    });
};

const obtenerProducto = (req, res) => {
    const { id } = req.params;

    obtenerProductoPorId(id, (error, producto) => {
        if (error) {
            return res.status(500).json({ mensaje: 'Error al obtener producto', error: error.message });
        }

        if (!producto) {
            return res.status(404).json({ mensaje: 'Producto no encontrado' });
        }

        res.json(producto);
    });
};

const agregarProducto = (req, res) => {
    const { nombre, categoria, precio, stock, descripcion } = req.body;

    if (!nombre || !categoria || precio === undefined || stock === undefined) {
        return res.status(400).json({ mensaje: 'Campos obligatorios faltantes' });
    }

    crearProducto(nombre, categoria, precio, stock, descripcion, (error, nuevoProducto) => {
        if (error) {
            return res.status(500).json({ mensaje: 'Error al crear producto', error: error.message });
        }

        if (stock > 0) {
            registrarMovimiento('entrada', stock, nuevoProducto.id, (errorHistorial) => {
                if (errorHistorial) {
                    console.error('Error al registrar movimiento inicial:', errorHistorial);
                }
            });
        }

        res.status(201).json({ mensaje: 'Producto creado exitosamente', producto: nuevoProducto });
    });
};

const modificarProducto = (req, res) => {
    const { id } = req.params;
    const { nombre, categoria, precio, stock, descripcion } = req.body;

    if (!nombre || !categoria || precio === undefined || stock === undefined) {
        return res.status(400).json({ mensaje: 'Campos obligatorios faltantes' });
    }

    obtenerProductoPorId(id, (error, productoAnterior) => {
        if (error) {
            return res.status(500).json({ mensaje: 'Error al obtener producto', error: error.message });
        }

        if (!productoAnterior) {
            return res.status(404).json({ mensaje: 'Producto no encontrado' });
        }

        actualizarProducto(id, nombre, categoria, precio, stock, descripcion, (errorActualizar, resultado) => {
            if (errorActualizar) {
                return res.status(500).json({ mensaje: 'Error al actualizar producto', error: errorActualizar.message });
            }

            const diferencia = stock - productoAnterior.stock;

            if (diferencia !== 0) {
                const tipoMovimiento = diferencia > 0 ? 'entrada' : 'salida';
                const cantidadMovimiento = Math.abs(diferencia);

                registrarMovimiento(tipoMovimiento, cantidadMovimiento, id, (errorHistorial) => {
                    if (errorHistorial) {
                        console.error('Error al registrar movimiento:', errorHistorial);
                    }
                });
            }

            res.json({ mensaje: 'Producto actualizado exitosamente', cambios: resultado.cambios });
        });
    });
};

const borrarProducto = (req, res) => {
    const { id } = req.params;

    eliminarProducto(id, (error, resultado) => {
        if (error) {
            return res.status(500).json({ mensaje: 'Error al eliminar producto', error: error.message });
        }

        if (resultado.cambios === 0) {
            return res.status(404).json({ mensaje: 'Producto no encontrado' });
        }

        res.json({ mensaje: 'Producto eliminado exitosamente' });
    });
};

module.exports = {
    listarProductos,
    obtenerProducto,
    agregarProducto,
    modificarProducto,
    borrarProducto
};
