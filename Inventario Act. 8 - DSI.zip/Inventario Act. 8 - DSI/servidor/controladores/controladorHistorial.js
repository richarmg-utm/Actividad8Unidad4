const { obtenerHistorialPorProducto, obtenerTodoElHistorial } = require('../modelos/HistorialMovimiento');

const listarHistorialCompleto = (req, res) => {
    obtenerTodoElHistorial((error, historial) => {
        if (error) {
            return res.status(500).json({ mensaje: 'Error al obtener historial', error: error.message });
        }
        res.json(historial);
    });
};

const listarHistorialProducto = (req, res) => {
    const { productoId } = req.params;

    obtenerHistorialPorProducto(productoId, (error, historial) => {
        if (error) {
            return res.status(500).json({ mensaje: 'Error al obtener historial del producto', error: error.message });
        }
        res.json(historial);
    });
};

module.exports = {
    listarHistorialCompleto,
    listarHistorialProducto
};
