const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const rutaBaseDatos = path.join(__dirname, '..', 'inventario.db');

const db = new sqlite3.Database(rutaBaseDatos, (error) => {
  if (error) {
    console.error('Error al conectar con la base de datos:', error.message);
  } else {
    console.log('Conectado a la base de datos SQLite');
  }
});

const inicializarTablas = () => {
  db.serialize(() => {
    db.run(`
      CREATE TABLE IF NOT EXISTS Usuario (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        correo TEXT UNIQUE NOT NULL,
        clave TEXT NOT NULL,
        rol TEXT DEFAULT 'usuario'
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS Producto (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        categoria TEXT NOT NULL,
        precio REAL NOT NULL,
        stock INTEGER NOT NULL DEFAULT 0,
        descripcion TEXT
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS HistorialMovimiento (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo TEXT NOT NULL CHECK(tipo IN ('entrada', 'salida')),
        cantidad INTEGER NOT NULL,
        fecha TEXT NOT NULL,
        producto_id INTEGER NOT NULL,
        FOREIGN KEY (producto_id) REFERENCES Producto(id) ON DELETE CASCADE
      )
    `);

    console.log('Tablas inicializadas correctamente');
  });
};

inicializarTablas();

module.exports = db;
