import { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { obtenerProductos, eliminarProducto } from '../servicios/api';
import { ContextoAuth } from '../contextos/ContextoAuth';
import FormularioProducto from '../componentes/FormularioProducto';

const PanelControl = () => {
    const [productos, setProductos] = useState([]);
    const [cargando, setCargando] = useState(true);
    const [error, setError] = useState('');
    const [mostrarFormulario, setMostrarFormulario] = useState(false);
    const [productoEditar, setProductoEditar] = useState(null);
    const [mensajeExito, setMensajeExito] = useState('');

    const { usuario, cerrarSesion } = useContext(ContextoAuth);
    const navegar = useNavigate();

    const cargarProductos = async () => {
        try {
            setCargando(true);
            const datos = await obtenerProductos();
            setProductos(datos);
            setError('');
        } catch (err) {
            setError(err.response?.data?.mensaje || 'Error al cargar productos');
        } finally {
            setCargando(false);
        }
    };

    useEffect(() => {
        cargarProductos();
    }, []);

    const manejarCerrarSesion = () => {
        cerrarSesion();
        navegar('/');
    };

    const manejarEliminar = async (id) => {
        if (!window.confirm('¿Estás seguro de eliminar este producto?')) {
            return;
        }

        try {
            await eliminarProducto(id);
            setMensajeExito('Producto eliminado exitosamente');
            cargarProductos();
            setTimeout(() => setMensajeExito(''), 3000);
        } catch (err) {
            setError(err.response?.data?.mensaje || 'Error al eliminar producto');
        }
    };

    const manejarEditar = (producto) => {
        setProductoEditar(producto);
        setMostrarFormulario(true);
    };

    const manejarNuevo = () => {
        setProductoEditar(null);
        setMostrarFormulario(true);
    };

    const manejarCerrarFormulario = () => {
        setMostrarFormulario(false);
        setProductoEditar(null);
    };

    const manejarExitoFormulario = () => {
        cargarProductos();
        setMostrarFormulario(false);
        setProductoEditar(null);
        setMensajeExito('Operación realizada exitosamente');
        setTimeout(() => setMensajeExito(''), 3000);
    };

    return (
        <div className="contenedor-panel">
            <header className="encabezado-panel">
                <div className="info-usuario">
                    <h1 className="titulo-panel">Panel de Control</h1>
                    <p className="bienvenida">Bienvenido, {usuario?.nombre}</p>
                </div>
                <button onClick={manejarCerrarSesion} className="boton-cerrar-sesion">
                    Cerrar Sesión
                </button>
            </header>

            <div className="contenido-panel">
                <div className="barra-acciones">
                    <h2 className="titulo-seccion">Gestión de Productos</h2>
                    <button onClick={manejarNuevo} className="boton-nuevo">
                        + Nuevo Producto
                    </button>
                </div>

                {mensajeExito && <div className="mensaje-exito">{mensajeExito}</div>}
                {error && <div className="mensaje-error">{error}</div>}

                {cargando ? (
                    <div className="cargando">Cargando productos...</div>
                ) : productos.length === 0 ? (
                    <div className="sin-productos">
                        <p>No hay productos registrados</p>
                        <button onClick={manejarNuevo} className="boton-primario">
                            Agregar Primer Producto
                        </button>
                    </div>
                ) : (
                    <div className="contenedor-tabla">
                        <table className="tabla-productos">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Descripción</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                {productos.map((producto) => (
                                    <tr key={producto.id}>
                                        <td>{producto.id}</td>
                                        <td>{producto.nombre}</td>
                                        <td>{producto.categoria}</td>
                                        <td>${producto.precio.toFixed(2)}</td>
                                        <td>
                                            <span className={`badge-stock ${producto.stock < 10 ? 'stock-bajo' : ''}`}>
                                                {producto.stock}
                                            </span>
                                        </td>
                                        <td>{producto.descripcion || 'Sin descripción'}</td>
                                        <td>
                                            <div className="acciones-tabla">
                                                <button
                                                    onClick={() => manejarEditar(producto)}
                                                    className="boton-editar"
                                                >
                                                    Editar
                                                </button>
                                                <button
                                                    onClick={() => manejarEliminar(producto.id)}
                                                    className="boton-eliminar"
                                                >
                                                    Eliminar
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {mostrarFormulario && (
                <FormularioProducto
                    producto={productoEditar}
                    alCerrar={manejarCerrarFormulario}
                    alExito={manejarExitoFormulario}
                />
            )}
        </div>
    );
};

export default PanelControl;
