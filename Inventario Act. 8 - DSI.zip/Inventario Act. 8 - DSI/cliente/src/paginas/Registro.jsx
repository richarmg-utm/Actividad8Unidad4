import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { registrarUsuario } from '../servicios/api';

const Registro = () => {
    const [nombre, setNombre] = useState('');
    const [correo, setCorreo] = useState('');
    const [clave, setClave] = useState('');
    const [confirmarClave, setConfirmarClave] = useState('');
    const [error, setError] = useState('');
    const [exito, setExito] = useState('');
    const [cargando, setCargando] = useState(false);

    const navegar = useNavigate();

    const manejarEnvio = async (e) => {
        e.preventDefault();
        setError('');
        setExito('');

        if (clave !== confirmarClave) {
            setError('Las contraseñas no coinciden');
            return;
        }

        if (clave.length < 6) {
            setError('La contraseña debe tener al menos 6 caracteres');
            return;
        }

        setCargando(true);

        try {
            await registrarUsuario({ nombre, correo, clave, rol: 'usuario' });
            setExito('Usuario registrado exitosamente. Redirigiendo...');
            setTimeout(() => {
                navegar('/');
            }, 2000);
        } catch (err) {
            setError(err.response?.data?.mensaje || 'Error al registrar usuario');
        } finally {
            setCargando(false);
        }
    };

    return (
        <div className="contenedor-registro">
            <div className="tarjeta-registro">
                <h1 className="titulo-registro">Crear Cuenta</h1>
                <p className="subtitulo-registro">Regístrate en el sistema de inventario</p>

                <form onSubmit={manejarEnvio} className="formulario-registro">
                    <div className="grupo-campo">
                        <label htmlFor="nombre" className="etiqueta-campo">Nombre Completo</label>
                        <input
                            type="text"
                            id="nombre"
                            value={nombre}
                            onChange={(e) => setNombre(e.target.value)}
                            className="campo-entrada"
                            placeholder="Juan Pérez"
                            required
                        />
                    </div>

                    <div className="grupo-campo">
                        <label htmlFor="correo" className="etiqueta-campo">Correo Electrónico</label>
                        <input
                            type="email"
                            id="correo"
                            value={correo}
                            onChange={(e) => setCorreo(e.target.value)}
                            className="campo-entrada"
                            placeholder="usuario@ejemplo.com"
                            required
                        />
                    </div>

                    <div className="grupo-campo">
                        <label htmlFor="clave" className="etiqueta-campo">Contraseña</label>
                        <input
                            type="password"
                            id="clave"
                            value={clave}
                            onChange={(e) => setClave(e.target.value)}
                            className="campo-entrada"
                            placeholder="••••••••"
                            required
                        />
                    </div>

                    <div className="grupo-campo">
                        <label htmlFor="confirmarClave" className="etiqueta-campo">Confirmar Contraseña</label>
                        <input
                            type="password"
                            id="confirmarClave"
                            value={confirmarClave}
                            onChange={(e) => setConfirmarClave(e.target.value)}
                            className="campo-entrada"
                            placeholder="••••••••"
                            required
                        />
                    </div>

                    {error && <div className="mensaje-error">{error}</div>}
                    {exito && <div className="mensaje-exito">{exito}</div>}

                    <button type="submit" className="boton-primario" disabled={cargando}>
                        {cargando ? 'Registrando...' : 'Registrarse'}
                    </button>
                </form>

                <p className="enlace-inicio-sesion">
                    ¿Ya tienes cuenta? <a href="/">Inicia sesión aquí</a>
                </p>
            </div>
        </div>
    );
};

export default Registro;
