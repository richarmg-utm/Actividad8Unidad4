import { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { iniciarSesion } from '../servicios/api';
import { ContextoAuth } from '../contextos/ContextoAuth';

const InicioSesion = () => {
    const [correo, setCorreo] = useState('');
    const [clave, setClave] = useState('');
    const [error, setError] = useState('');
    const [cargando, setCargando] = useState(false);

    const { iniciarSesion: guardarSesion } = useContext(ContextoAuth);
    const navegar = useNavigate();

    const manejarEnvio = async (e) => {
        e.preventDefault();
        setError('');
        setCargando(true);

        try {
            const respuesta = await iniciarSesion({ correo, clave });
            guardarSesion(respuesta.token, respuesta.usuario);
            navegar('/panel');
        } catch (err) {
            setError(err.response?.data?.mensaje || 'Error al iniciar sesión');
        } finally {
            setCargando(false);
        }
    };

    return (
        <div className="contenedor-inicio-sesion">
            <div className="tarjeta-inicio-sesion">
                <h1 className="titulo-inicio-sesion">Iniciar Sesión</h1>
                <p className="subtitulo-inicio-sesion">Sistema de Gestión de Inventario</p>

                <form onSubmit={manejarEnvio} className="formulario-inicio-sesion">
                    <div className="grupo-campo">
                        <label htmlFor="correo" className="etiqueta-campo">Correo Electrónico</label>
                        <input
                            type="email"
                            id="correo"
                            value={correo}
                            onChange={(e) => setCorreo(e.target.value)}
                            className="campo-entrada"
                            placeholder="usuario@ejemplo.com"
                            required
                        />
                    </div>

                    <div className="grupo-campo">
                        <label htmlFor="clave" className="etiqueta-campo">Contraseña</label>
                        <input
                            type="password"
                            id="clave"
                            value={clave}
                            onChange={(e) => setClave(e.target.value)}
                            className="campo-entrada"
                            placeholder="••••••••"
                            required
                        />
                    </div>

                    {error && <div className="mensaje-error">{error}</div>}

                    <button type="submit" className="boton-primario" disabled={cargando}>
                        {cargando ? 'Iniciando sesión...' : 'Iniciar Sesión'}
                    </button>
                </form>

                <p className="enlace-registro">
                    ¿No tienes cuenta? <a href="/registro">Regístrate aquí</a>
                </p>
            </div>
        </div>
    );
};

export default InicioSesion;
