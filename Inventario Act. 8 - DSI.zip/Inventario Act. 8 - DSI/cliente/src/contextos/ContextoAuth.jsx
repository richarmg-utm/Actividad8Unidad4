import { createContext, useState, useEffect } from 'react';

export const ContextoAuth = createContext();

export const ProveedorAuth = ({ children }) => {
    const [token, setToken] = useState(null);
    const [usuario, setUsuario] = useState(null);
    const [cargando, setCargando] = useState(true);

    useEffect(() => {
        const tokenGuardado = localStorage.getItem('token');
        const usuarioGuardado = localStorage.getItem('usuario');

        if (tokenGuardado && usuarioGuardado) {
            setToken(tokenGuardado);
            setUsuario(JSON.parse(usuarioGuardado));
        }
        setCargando(false);
    }, []);

    const iniciarSesion = (nuevoToken, nuevoUsuario) => {
        setToken(nuevoToken);
        setUsuario(nuevoUsuario);
        localStorage.setItem('token', nuevoToken);
        localStorage.setItem('usuario', JSON.stringify(nuevoUsuario));
    };

    const cerrarSesion = () => {
        setToken(null);
        setUsuario(null);
        localStorage.removeItem('token');
        localStorage.removeItem('usuario');
    };

    return (
        <ContextoAuth.Provider value={{ token, usuario, iniciarSesion, cerrarSesion, cargando }}>
            {children}
        </ContextoAuth.Provider>
    );
};
