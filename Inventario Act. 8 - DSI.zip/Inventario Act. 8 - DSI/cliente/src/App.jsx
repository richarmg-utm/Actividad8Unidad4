import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ProveedorAuth } from './contextos/ContextoAuth';
import RutaProtegida from './componentes/RutaProtegida';
import InicioSesion from './paginas/InicioSesion';
import Registro from './paginas/Registro';
import PanelControl from './paginas/PanelControl';
import './App.css';

function App() {
    return (
        <ProveedorAuth>
            <Router>
                <Routes>
                    <Route path="/" element={<InicioSesion />} />
                    <Route path="/registro" element={<Registro />} />
                    <Route
                        path="/panel"
                        element={
                            <RutaProtegida>
                                <PanelControl />
                            </RutaProtegida>
                        }
                    />
                </Routes>
            </Router>
        </ProveedorAuth>
    );
}

export default App;
