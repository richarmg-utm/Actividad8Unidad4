import { useState, useEffect } from 'react';
import { crearProducto, actualizarProducto } from '../servicios/api';

const FormularioProducto = ({ producto, alCerrar, alExito }) => {
    const [nombre, setNombre] = useState('');
    const [categoria, setCategoria] = useState('');
    const [precio, setPrecio] = useState('');
    const [stock, setStock] = useState('');
    const [descripcion, setDescripcion] = useState('');
    const [error, setError] = useState('');
    const [cargando, setCargando] = useState(false);

    useEffect(() => {
        if (producto) {
            setNombre(producto.nombre);
            setCategoria(producto.categoria);
            setPrecio(producto.precio.toString());
            setStock(producto.stock.toString());
            setDescripcion(producto.descripcion || '');
        }
    }, [producto]);

    const manejarEnvio = async (e) => {
        e.preventDefault();
        setError('');
        setCargando(true);

        const datosProducto = {
            nombre,
            categoria,
            precio: parseFloat(precio),
            stock: parseInt(stock),
            descripcion
        };

        try {
            if (producto) {
                await actualizarProducto(producto.id, datosProducto);
            } else {
                await crearProducto(datosProducto);
            }
            alExito();
        } catch (err) {
            setError(err.response?.data?.mensaje || 'Error al guardar producto');
        } finally {
            setCargando(false);
        }
    };

    return (
        <div className="modal-overlay" onClick={alCerrar}>
            <div className="modal-contenido" onClick={(e) => e.stopPropagation()}>
                <div className="modal-encabezado">
                    <h2>{producto ? 'Editar Producto' : 'Nuevo Producto'}</h2>
                    <button onClick={alCerrar} className="boton-cerrar-modal">×</button>
                </div>

                <form onSubmit={manejarEnvio} className="formulario-producto">
                    <div className="grupo-campo">
                        <label htmlFor="nombre" className="etiqueta-campo">Nombre del Producto</label>
                        <input
                            type="text"
                            id="nombre"
                            value={nombre}
                            onChange={(e) => setNombre(e.target.value)}
                            className="campo-entrada"
                            placeholder="Ej: Laptop Dell"
                            required
                        />
                    </div>

                    <div className="grupo-campo">
                        <label htmlFor="categoria" className="etiqueta-campo">Categoría</label>
                        <input
                            type="text"
                            id="categoria"
                            value={categoria}
                            onChange={(e) => setCategoria(e.target.value)}
                            className="campo-entrada"
                            placeholder="Ej: Electrónica"
                            required
                        />
                    </div>

                    <div className="grupo-doble">
                        <div className="grupo-campo">
                            <label htmlFor="precio" className="etiqueta-campo">Precio</label>
                            <input
                                type="number"
                                id="precio"
                                value={precio}
                                onChange={(e) => setPrecio(e.target.value)}
                                className="campo-entrada"
                                placeholder="0.00"
                                step="0.01"
                                min="0"
                                required
                            />
                        </div>

                        <div className="grupo-campo">
                            <label htmlFor="stock" className="etiqueta-campo">Stock</label>
                            <input
                                type="number"
                                id="stock"
                                value={stock}
                                onChange={(e) => setStock(e.target.value)}
                                className="campo-entrada"
                                placeholder="0"
                                min="0"
                                required
                            />
                        </div>
                    </div>

                    <div className="grupo-campo">
                        <label htmlFor="descripcion" className="etiqueta-campo">Descripción</label>
                        <textarea
                            id="descripcion"
                            value={descripcion}
                            onChange={(e) => setDescripcion(e.target.value)}
                            className="campo-textarea"
                            placeholder="Descripción del producto..."
                            rows="3"
                        />
                    </div>

                    {error && <div className="mensaje-error">{error}</div>}

                    <div className="acciones-formulario">
                        <button type="button" onClick={alCerrar} className="boton-secundario">
                            Cancelar
                        </button>
                        <button type="submit" className="boton-primario" disabled={cargando}>
                            {cargando ? 'Guardando...' : 'Guardar'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default FormularioProducto;
