import { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { ContextoAuth } from '../contextos/ContextoAuth';

const RutaProtegida = ({ children }) => {
    const { token, cargando } = useContext(ContextoAuth);

    if (cargando) {
        return <div className="cargando-pantalla">Cargando...</div>;
    }

    if (!token) {
        return <Navigate to="/" replace />;
    }

    return children;
};

export default RutaProtegida;
