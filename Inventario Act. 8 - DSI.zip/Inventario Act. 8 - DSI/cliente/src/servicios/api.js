import axios from 'axios';

const URL_BASE = 'http://localhost:5000/api';

const instanciaAxios = axios.create({
    baseURL: URL_BASE,
    headers: {
        'Content-Type': 'application/json'
    }
});

instanciaAxios.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

export const registrarUsuario = async (datosUsuario) => {
    const respuesta = await instanciaAxios.post('/usuarios/registro', datosUsuario);
    return respuesta.data;
};

export const iniciarSesion = async (credenciales) => {
    const respuesta = await instanciaAxios.post('/usuarios/login', credenciales);
    return respuesta.data;
};

export const obtenerProductos = async () => {
    const respuesta = await instanciaAxios.get('/productos');
    return respuesta.data;
};

export const obtenerProductoPorId = async (id) => {
    const respuesta = await instanciaAxios.get(`/productos/${id}`);
    return respuesta.data;
};

export const crearProducto = async (datosProducto) => {
    const respuesta = await instanciaAxios.post('/productos', datosProducto);
    return respuesta.data;
};

export const actualizarProducto = async (id, datosProducto) => {
    const respuesta = await instanciaAxios.put(`/productos/${id}`, datosProducto);
    return respuesta.data;
};

export const eliminarProducto = async (id) => {
    const respuesta = await instanciaAxios.delete(`/productos/${id}`);
    return respuesta.data;
};

export const obtenerHistorial = async () => {
    const respuesta = await instanciaAxios.get('/historial');
    return respuesta.data;
};

export const obtenerHistorialProducto = async (productoId) => {
    const respuesta = await instanciaAxios.get(`/historial/producto/${productoId}`);
    return respuesta.data;
};

export default instanciaAxios;
